const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mysql = require('mysql');

const app = express();

// Enable CORS
app.use(cors());

// Configure body-parser to handle POST requests
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Create a MySQL connection pool
const pool = mysql.createPool({
  host: '...',
  user: '...',
  password: '...',
  database: '...',
});


function contains(val, col_name, table_name){

}

export function diff_lang(country1, country2){

}

export function diff_lang_join(country1, country2){

}


export function aggregate_countries(agg_type, country_name) {

}

function find_min_max_continent() {
  
}

function find_country_languages(percentage, language) {

}

function find_country_count(amount) {

}



app.get('/getDiffLang', (req, res) => {
    diff_lang(country1, country2 , (error, results) => {

    });
});


app.get('/getDiffLangJoin', (req, res) => {
    diff_lang_join(country1, country2 , (error, results) => {
        
    });
});


app.get('/aggregateCountries', (req, res) => {
  aggregate_countries(agg_type, country_name , (error, results) => {
      
  });
});
