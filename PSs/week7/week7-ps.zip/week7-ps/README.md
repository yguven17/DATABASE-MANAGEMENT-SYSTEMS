# Part 1 of PS

Before using the webpage, don't forget to run the server (aka index.js) with the "node index.js" command.

## Libaries

 - MySQL
 - Express
 - Cors
 - Body-Parser

You can download all the required libraries with the following command

    npm install mysql express cors body-parser

